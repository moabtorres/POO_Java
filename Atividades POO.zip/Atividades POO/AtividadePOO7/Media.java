package AtividadePOO7;

public class Media {

    
    public static void main(String[] args) {
       Notas teste = new Notas();
       teste.Calcular();
    }
    
}
