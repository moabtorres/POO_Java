
package AtividadePOO10;


public class Atv10raclog {

  
    public static void main(String[] args) {
      
        int idadeJoaquim,idadeLucio,Soma;
        
        Soma = 60;
        idadeLucio = Soma / 4;
        idadeJoaquim = idadeLucio * 3;
        
        System.out.println("A idade de Joaquim e " + idadeJoaquim + ", e a de Lucio e " + idadeLucio);
    }
    
}
