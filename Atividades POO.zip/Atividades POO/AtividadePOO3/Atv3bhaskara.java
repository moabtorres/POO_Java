package AtividadePOO3;

public class Atv3bhaskara {

  
    public static void main(String[] args) {
      calculo teste = new calculo();
        teste.calcular();
    }
    
}
